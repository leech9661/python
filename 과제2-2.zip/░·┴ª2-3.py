inStr = input('문자열을 입력--->')
#2018038089 이광희 과제2-3
for i in range(len(inStr)-1,-1,-1):
    print('%c' % inStr[i], end='')
